package io.northstar.behavior.dto;

public record SchoolDTO(
        Long schoolId,
        String schoolName,
        Long districtId
) {}
