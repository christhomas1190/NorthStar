package io.northstar.behavior.dto;

public record DistrictLimitDTO(Long districtId, int maxSchools, long currentSchools) {}

