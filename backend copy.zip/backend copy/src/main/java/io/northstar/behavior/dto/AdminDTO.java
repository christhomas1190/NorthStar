package io.northstar.behavior.dto;

public record AdminDTO(
        Long id,
        String firstName,
        String lastName,
        String email,
        String userName,
        String permissionTag,
        Long districtId
) {}
