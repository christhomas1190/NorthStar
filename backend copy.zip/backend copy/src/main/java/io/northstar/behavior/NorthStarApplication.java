package io.northstar.behavior;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NorthStarApplication {
  public static void main(String[] args) {
    SpringApplication.run(NorthStarApplication.class, args);
  }
}
