package io.northstar.behavior.dto;

public record DistrictDTO (Long id,
                          String districtName)

{}
